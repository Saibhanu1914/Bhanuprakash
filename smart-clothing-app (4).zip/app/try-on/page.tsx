"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, ArrowRight, Heart, ShoppingCart } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"

export default function TryOnPage() {
  const [selectedProduct, setSelectedProduct] = useState(0)
  const [selectedSize, setSelectedSize] = useState("M")
  const [selectedColor, setSelectedColor] = useState("Black")

  const products = [
    {
      id: 0,
      name: "Classic Fit T-Shirt",
      price: "$29.99",
      fit: "Perfect fit",
      image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=300&h=400&auto=format&fit=crop&q=80",
    },
    {
      id: 1,
      name: "Slim Fit Jeans",
      price: "$59.99",
      fit: "Slightly tight",
      image: "https://images.unsplash.com/photo-1542272604-787c3835535d?w=300&h=400&auto=format&fit=crop&q=80",
    },
    {
      id: 2,
      name: "Casual Blazer",
      price: "$89.99",
      fit: "Perfect fit",
      image: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=300&h=400&auto=format&fit=crop&q=80",
    },
    {
      id: 3,
      name: "Summer Dress",
      price: "$49.99",
      fit: "Slightly loose",
      image: "https://images.unsplash.com/photo-1612336307429-8a898d10e223?w=300&h=400&auto=format&fit=crop&q=80",
    },
    {
      id: 4,
      name: "Formal Shirt",
      price: "$39.99",
      fit: "Perfect fit",
      image: "https://images.unsplash.com/photo-1598033129183-c4f50c736f10?w=300&h=400&auto=format&fit=crop&q=80",
    },
  ]

  return (
    <div className="container py-10">
      <div className="flex flex-col space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Virtual Try-On</h1>
            <p className="text-muted-foreground">See how clothes fit your body before you buy.</p>
          </div>
          <Link href="/measure">
            <Button variant="outline">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Measurements
            </Button>
          </Link>
        </div>

        <div className="grid lg:grid-cols-[1fr_400px] gap-8">
          <div className="flex flex-col gap-6">
            <div className="aspect-[3/4] relative bg-muted rounded-lg overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-b from-purple-50 to-purple-100 z-0"></div>
              <Image
                src="https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcQ0wyfQr9e8DZC-0YR203XtG2PefpchisOOMRJ1CUZqD7RtN4Worpr4Xrsav3lC1IJq-Tcejb5LMQxh6-NWTxQo9h_vnd6YECjkDxVuIHmtJu6P2cO_pk64"
                alt="Virtual try-on avatar"
                fill
                className="object-cover z-10"
                unoptimized
              />
              <div className="absolute top-0 left-0 w-full h-full z-20 pointer-events-none">
                <div className="absolute top-4 left-4 bg-white/80 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-medium text-purple-700">
                  Virtual Model
                </div>
              </div>
              <Badge className="absolute top-4 right-4 bg-green-500 text-white z-20">Perfect fit</Badge>
            </div>

            <div className="flex justify-between">
              <Button variant="outline" size="sm">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Previous View
              </Button>
              <Button variant="outline" size="sm">
                Next View
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="flex flex-col gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="space-y-6">
                  <div>
                    <h2 className="text-2xl font-semibold">{products[selectedProduct].name}</h2>
                    <p className="text-xl font-medium text-primary">{products[selectedProduct].price}</p>
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <div>
                      <h3 className="font-medium mb-2">Size</h3>
                      <div className="flex flex-wrap gap-2">
                        {["XS", "S", "M", "L", "XL", "XXL"].map((size) => (
                          <Button
                            key={size}
                            variant={selectedSize === size ? "default" : "outline"}
                            size="sm"
                            onClick={() => setSelectedSize(size)}
                          >
                            {size}
                          </Button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h3 className="font-medium mb-2">Color</h3>
                      <div className="flex flex-wrap gap-2">
                        {["Black", "White", "Navy", "Gray", "Red"].map((color) => (
                          <Button
                            key={color}
                            variant={selectedColor === color ? "default" : "outline"}
                            size="sm"
                            onClick={() => setSelectedColor(color)}
                          >
                            {color}
                          </Button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <h3 className="font-medium">Fit Analysis</h3>
                    <div className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>Shoulders</span>
                        <span className="text-green-500 font-medium">Perfect fit</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Chest</span>
                        <span className="text-green-500 font-medium">Perfect fit</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Waist</span>
                        <span className="text-yellow-500 font-medium">Slightly loose</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Length</span>
                        <span className="text-green-500 font-medium">Perfect fit</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <Button className="flex-1">
                      <ShoppingCart className="mr-2 h-4 w-4" />
                      Add to Cart
                    </Button>
                    <Button variant="outline">
                      <Heart className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-4">
              <h3 className="font-medium">Try On More Products</h3>
              <ScrollArea>
                <div className="flex gap-4 pb-4">
                  {products.map((product) => (
                    <div
                      key={product.id}
                      className={`flex-none w-[150px] cursor-pointer rounded-md overflow-hidden border-2 ${selectedProduct === product.id ? "border-primary" : "border-transparent"}`}
                      onClick={() => setSelectedProduct(product.id)}
                    >
                      <div className="aspect-[3/4] relative bg-muted">
                        <Image
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          fill
                          className="object-cover"
                          unoptimized
                        />
                      </div>
                      <div className="p-2">
                        <p className="text-sm font-medium truncate">{product.name}</p>
                        <p className="text-sm text-muted-foreground">{product.price}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <ScrollBar orientation="horizontal" />
              </ScrollArea>
            </div>

            <div className="flex justify-end">
              <Link href="/checkout">
                <Button>
                  Proceed to Checkout
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
