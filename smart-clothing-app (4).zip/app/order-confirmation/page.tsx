import Link from "next/link"
import { ArrowRight, Check, Package, Truck } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"

export default function OrderConfirmationPage() {
  return (
    <div className="container max-w-2xl py-10">
      <div className="flex flex-col space-y-8 items-center text-center">
        <div className="rounded-full bg-primary/10 p-6">
          <Check className="h-12 w-12 text-primary" />
        </div>

        <div>
          <h1 className="text-3xl font-bold tracking-tight">Order Confirmed!</h1>
          <p className="text-muted-foreground mt-2">Thank you for your purchase. Your order has been confirmed.</p>
        </div>

        <Card className="w-full">
          <CardHeader>
            <CardTitle>Order #12345</CardTitle>
            <CardDescription>Placed on April 14, 2025</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="space-y-2">
                <h3 className="font-medium">Shipping Status</h3>
                <div className="relative">
                  <div className="flex items-center justify-between">
                    <div className="flex flex-col items-center">
                      <div className="rounded-full bg-primary p-2">
                        <Check className="h-4 w-4 text-primary-foreground" />
                      </div>
                      <p className="text-xs mt-1">Confirmed</p>
                    </div>
                    <div className="flex flex-col items-center">
                      <div className="rounded-full bg-muted p-2">
                        <Package className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <p className="text-xs mt-1">Processing</p>
                    </div>
                    <div className="flex flex-col items-center">
                      <div className="rounded-full bg-muted p-2">
                        <Truck className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <p className="text-xs mt-1">Shipped</p>
                    </div>
                    <div className="flex flex-col items-center">
                      <div className="rounded-full bg-muted p-2">
                        <Check className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <p className="text-xs mt-1">Delivered</p>
                    </div>
                  </div>
                  <div className="absolute top-5 left-0 right-0 h-[2px] bg-muted -z-10">
                    <div className="h-full w-[15%] bg-primary"></div>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <h3 className="font-medium">Shipping Information</h3>
                <div className="text-sm">
                  <p>John Doe</p>
                  <p>123 Main St</p>
                  <p>New York, NY 10001</p>
                  <p>United States</p>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <h3 className="font-medium">Order Summary</h3>
                <div className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span>Classic Fit T-Shirt (Black, M)</span>
                    <span>$29.99</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Shipping</span>
                    <span>Free</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Tax</span>
                    <span>$2.40</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-medium">
                    <span>Total</span>
                    <span>$32.39</span>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="font-medium">Estimated Delivery</h3>
                <p className="text-sm">April 17-19, 2025</p>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-center">
            <Link href="/track-order">
              <Button>
                Track Your Order
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </CardFooter>
        </Card>

        <div className="space-y-4">
          <h2 className="text-xl font-semibold">What's Next?</h2>
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Track Your Order</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Follow your package from our warehouse to your doorstep.
                </p>
              </CardContent>
              <CardFooter>
                <Link href="/track-order" className="text-sm text-primary hover:underline">
                  View Tracking Details
                </Link>
              </CardFooter>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Continue Shopping</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Discover more perfectly fitting clothes for your wardrobe.
                </p>
              </CardContent>
              <CardFooter>
                <Link href="/" className="text-sm text-primary hover:underline">
                  Back to Home
                </Link>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
