import Link from "next/link"
import { ArrowRight, Ruler, ShoppingBag, Shirt, TruckIcon } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-16 flex items-center border-b">
        <Link className="flex items-center justify-center" href="#">
          <ShoppingBag className="h-6 w-6 mr-2" />
          <span className="font-bold">FitFashion</span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Shop
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Try On
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            My Account
          </Link>
        </nav>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Perfect Fit, Every Time</h1>
                <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                  Measure once, shop confidently. Our smart body measurement and virtual try-on technology ensures your
                  clothes fit perfectly.
                </p>
              </div>
              <div className="space-x-4">
                <Link href="/measure">
                  <Button>
                    Get Started
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
                <Link href="/how-it-works">
                  <Button variant="outline">How It Works</Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-3 lg:gap-12">
              <Card>
                <CardHeader>
                  <Ruler className="h-10 w-10 mb-2 text-primary" />
                  <CardTitle>Smart Measurements</CardTitle>
                  <CardDescription>
                    Take accurate body measurements using our guided process or upload existing measurements.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p>
                    Our technology captures precise body measurements to create your digital profile, ensuring perfect
                    fitting clothes every time.
                  </p>
                </CardContent>
                <CardFooter>
                  <Link href="/measure">
                    <Button variant="outline" size="sm">
                      Start Measuring
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
              <Card>
                <CardHeader>
                  <Shirt className="h-10 w-10 mb-2 text-primary" />
                  <CardTitle>Virtual Try-On</CardTitle>
                  <CardDescription>See how clothes look on your digital avatar before you buy.</CardDescription>
                </CardHeader>
                <CardContent>
                  <p>
                    Our virtual try-on technology lets you see exactly how garments will fit your unique body shape and
                    size.
                  </p>
                </CardContent>
                <CardFooter>
                  <Link href="/try-on">
                    <Button variant="outline" size="sm">
                      Try Clothes On
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
              <Card>
                <CardHeader>
                  <TruckIcon className="h-10 w-10 mb-2 text-primary" />
                  <CardTitle>Seamless Delivery</CardTitle>
                  <CardDescription>Track your perfect-fitting clothes from purchase to delivery.</CardDescription>
                </CardHeader>
                <CardContent>
                  <p>
                    Once you've found your perfect fit, complete your purchase and track your order all the way to your
                    doorstep.
                  </p>
                </CardContent>
                <CardFooter>
                  <Link href="/shop">
                    <Button variant="outline" size="sm">
                      Shop Now
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            </div>
          </div>
        </section>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full border-t px-4 md:px-6">
        <p className="text-xs text-muted-foreground">© 2025 FitFashion. All rights reserved.</p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Terms of Service
          </Link>
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Privacy
          </Link>
        </nav>
      </footer>
    </div>
  )
}
