"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Check, Package, Truck } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function TrackOrderPage() {
  const [trackingTab, setTrackingTab] = useState("current")

  return (
    <div className="container max-w-3xl py-10">
      <div className="flex flex-col space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Track Your Order</h1>
            <p className="text-muted-foreground">Follow your package from our warehouse to your doorstep.</p>
          </div>
          <Link href="/">
            <Button variant="outline">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Order #12345</CardTitle>
            <CardDescription>Placed on April 14, 2025</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="space-y-2">
                <h3 className="font-medium">Shipping Status</h3>
                <div className="relative">
                  <div className="flex items-center justify-between">
                    <div className="flex flex-col items-center">
                      <div className="rounded-full bg-primary p-2">
                        <Check className="h-4 w-4 text-primary-foreground" />
                      </div>
                      <p className="text-xs mt-1">Confirmed</p>
                    </div>
                    <div className="flex flex-col items-center">
                      <div className="rounded-full bg-primary p-2">
                        <Package className="h-4 w-4 text-primary-foreground" />
                      </div>
                      <p className="text-xs mt-1">Processing</p>
                    </div>
                    <div className="flex flex-col items-center">
                      <div className="rounded-full bg-muted p-2">
                        <Truck className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <p className="text-xs mt-1">Shipped</p>
                    </div>
                    <div className="flex flex-col items-center">
                      <div className="rounded-full bg-muted p-2">
                        <Check className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <p className="text-xs mt-1">Delivered</p>
                    </div>
                  </div>
                  <div className="absolute top-5 left-0 right-0 h-[2px] bg-muted -z-10">
                    <div className="h-full w-[35%] bg-primary"></div>
                  </div>
                </div>
              </div>

              <Tabs value={trackingTab} onValueChange={setTrackingTab}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="current">Current Status</TabsTrigger>
                  <TabsTrigger value="history">Tracking History</TabsTrigger>
                </TabsList>

                <TabsContent value="current" className="pt-6">
                  <div className="space-y-4">
                    <div className="bg-muted/50 p-4 rounded-lg">
                      <div className="flex items-start gap-4">
                        <Package className="h-6 w-6 text-primary mt-1" />
                        <div>
                          <h4 className="font-medium">Order Processing</h4>
                          <p className="text-sm text-muted-foreground">
                            Your order is being prepared for shipment. We're carefully packing your perfectly fitted
                            clothes.
                          </p>
                          <p className="text-sm font-medium mt-1">April 15, 2025 at 10:30 AM</p>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <h3 className="font-medium">Estimated Delivery</h3>
                      <p className="text-sm">April 17-19, 2025</p>
                    </div>

                    <Separator />

                    <div className="space-y-2">
                      <h3 className="font-medium">Shipping Information</h3>
                      <div className="text-sm">
                        <p>John Doe</p>
                        <p>123 Main St</p>
                        <p>New York, NY 10001</p>
                        <p>United States</p>
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-2">
                      <h3 className="font-medium">Shipping Method</h3>
                      <p className="text-sm">Standard Shipping (3-5 business days)</p>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="history" className="pt-6">
                  <div className="space-y-4">
                    <div className="space-y-4">
                      <div className="flex items-start gap-4">
                        <div className="min-w-[100px] text-sm text-right text-muted-foreground">Apr 15, 10:30 AM</div>
                        <div className="relative">
                          <div className="absolute top-1 left-[-17px] w-3 h-3 rounded-full bg-primary"></div>
                          <div className="absolute top-4 bottom-0 left-[-16px] w-[2px] bg-muted"></div>
                          <div>
                            <h4 className="text-sm font-medium">Order Processing</h4>
                            <p className="text-sm text-muted-foreground">Your order is being prepared for shipment.</p>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-start gap-4">
                        <div className="min-w-[100px] text-sm text-right text-muted-foreground">Apr 14, 3:45 PM</div>
                        <div className="relative">
                          <div className="absolute top-1 left-[-17px] w-3 h-3 rounded-full bg-primary"></div>
                          <div className="absolute top-4 bottom-0 left-[-16px] w-[2px] bg-muted"></div>
                          <div>
                            <h4 className="text-sm font-medium">Payment Confirmed</h4>
                            <p className="text-sm text-muted-foreground">
                              Your payment has been successfully processed.
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-start gap-4">
                        <div className="min-w-[100px] text-sm text-right text-muted-foreground">Apr 14, 3:30 PM</div>
                        <div className="relative">
                          <div className="absolute top-1 left-[-17px] w-3 h-3 rounded-full bg-primary"></div>
                          <div>
                            <h4 className="text-sm font-medium">Order Placed</h4>
                            <p className="text-sm text-muted-foreground">Your order has been received and confirmed.</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>

              <div className="space-y-4">
                <h3 className="font-medium">Track Another Order</h3>
                <div className="flex gap-4">
                  <div className="flex-1 space-y-2">
                    <Label htmlFor="order-number">Order Number</Label>
                    <Input id="order-number" placeholder="Enter order number" />
                  </div>
                  <div className="flex items-end">
                    <Button>Track</Button>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-center">
          <Link href="/">
            <Button variant="outline">Continue Shopping</Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
