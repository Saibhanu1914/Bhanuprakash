"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, ArrowRight, CreditCard, Truck } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function CheckoutPage() {
  const [checkoutStep, setCheckoutStep] = useState("shipping")

  return (
    <div className="container max-w-4xl py-10">
      <div className="flex flex-col space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Checkout</h1>
            <p className="text-muted-foreground">Complete your purchase and get ready for delivery.</p>
          </div>
          <Link href="/try-on">
            <Button variant="outline">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Try-On
            </Button>
          </Link>
        </div>

        <div className="grid md:grid-cols-[1fr_300px] gap-8">
          <div className="flex flex-col gap-6">
            <Tabs value={checkoutStep} onValueChange={setCheckoutStep}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="shipping">Shipping</TabsTrigger>
                <TabsTrigger value="payment">Payment</TabsTrigger>
                <TabsTrigger value="review">Review</TabsTrigger>
              </TabsList>

              <TabsContent value="shipping" className="pt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Shipping Information</CardTitle>
                    <CardDescription>
                      Enter your shipping details to receive your perfectly fitted clothes.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form className="grid gap-6">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="first-name">First Name</Label>
                          <Input id="first-name" placeholder="John" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="last-name">Last Name</Label>
                          <Input id="last-name" placeholder="Doe" />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="address">Address</Label>
                        <Input id="address" placeholder="123 Main St" />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="city">City</Label>
                          <Input id="city" placeholder="New York" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="postal-code">Postal Code</Label>
                          <Input id="postal-code" placeholder="10001" />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="country">Country</Label>
                        <Input id="country" placeholder="United States" />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number</Label>
                        <Input id="phone" placeholder="+1 (555) 123-4567" />
                      </div>

                      <div className="space-y-2">
                        <Label>Shipping Method</Label>
                        <RadioGroup defaultValue="standard">
                          <div className="flex items-center justify-between space-x-2 border p-4 rounded-md">
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="standard" id="standard" />
                              <Label htmlFor="standard" className="font-normal">
                                Standard Shipping (3-5 days)
                              </Label>
                            </div>
                            <span>Free</span>
                          </div>
                          <div className="flex items-center justify-between space-x-2 border p-4 rounded-md">
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="express" id="express" />
                              <Label htmlFor="express" className="font-normal">
                                Express Shipping (1-2 days)
                              </Label>
                            </div>
                            <span>$9.99</span>
                          </div>
                        </RadioGroup>
                      </div>
                    </form>
                  </CardContent>
                  <CardFooter>
                    <Button className="ml-auto" onClick={() => setCheckoutStep("payment")}>
                      Continue to Payment
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>

              <TabsContent value="payment" className="pt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Payment Information</CardTitle>
                    <CardDescription>Enter your payment details to complete your purchase.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form className="grid gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="card-number">Card Number</Label>
                        <Input id="card-number" placeholder="1234 5678 9012 3456" />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="expiry-date">Expiry Date</Label>
                          <Input id="expiry-date" placeholder="MM/YY" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="cvv">CVV</Label>
                          <Input id="cvv" placeholder="123" />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="name-on-card">Name on Card</Label>
                        <Input id="name-on-card" placeholder="John Doe" />
                      </div>

                      <div className="space-y-2">
                        <Label>Payment Method</Label>
                        <RadioGroup defaultValue="credit-card">
                          <div className="flex items-center justify-between space-x-2 border p-4 rounded-md">
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="credit-card" id="credit-card" />
                              <Label htmlFor="credit-card" className="font-normal">
                                Credit Card
                              </Label>
                            </div>
                            <CreditCard className="h-4 w-4 text-muted-foreground" />
                          </div>
                          <div className="flex items-center justify-between space-x-2 border p-4 rounded-md">
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="paypal" id="paypal" />
                              <Label htmlFor="paypal" className="font-normal">
                                PayPal
                              </Label>
                            </div>
                            <Image src="/placeholder.svg?height=16&width=16" width={16} height={16} alt="PayPal" />
                          </div>
                        </RadioGroup>
                      </div>
                    </form>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" onClick={() => setCheckoutStep("shipping")}>
                      <ArrowLeft className="mr-2 h-4 w-4" />
                      Back to Shipping
                    </Button>
                    <Button onClick={() => setCheckoutStep("review")}>
                      Continue to Review
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>

              <TabsContent value="review" className="pt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Review Your Order</CardTitle>
                    <CardDescription>Review your order details before finalizing your purchase.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-6">
                      <div className="space-y-3">
                        <h3 className="font-medium">Items</h3>
                        <div className="border rounded-md">
                          <div className="flex items-center p-4 gap-4">
                            <div className="h-16 w-16 relative bg-muted rounded">
                              <Image
                                src="/placeholder.svg?height=64&width=64"
                                alt="Product thumbnail"
                                fill
                                className="object-cover"
                              />
                            </div>
                            <div className="flex-1">
                              <h4 className="font-medium">Classic Fit T-Shirt</h4>
                              <p className="text-sm text-muted-foreground">Size: M, Color: Black</p>
                            </div>
                            <div className="text-right">
                              <p className="font-medium">$29.99</p>
                              <p className="text-sm text-muted-foreground">Qty: 1</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <Separator />

                      <div className="space-y-3">
                        <h3 className="font-medium">Shipping Information</h3>
                        <div className="text-sm">
                          <p>John Doe</p>
                          <p>123 Main St</p>
                          <p>New York, NY 10001</p>
                          <p>United States</p>
                          <p>+1 (555) 123-4567</p>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Truck className="h-4 w-4 text-muted-foreground" />
                          <span>Standard Shipping (3-5 days)</span>
                        </div>
                      </div>

                      <Separator />

                      <div className="space-y-3">
                        <h3 className="font-medium">Payment Information</h3>
                        <div className="text-sm">
                          <p>Credit Card ending in 3456</p>
                          <p>John Doe</p>
                        </div>
                      </div>

                      <Separator />

                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span>Subtotal</span>
                          <span>$29.99</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Shipping</span>
                          <span>Free</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Tax</span>
                          <span>$2.40</span>
                        </div>
                        <Separator />
                        <div className="flex justify-between font-medium text-lg">
                          <span>Total</span>
                          <span>$32.39</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" onClick={() => setCheckoutStep("payment")}>
                      <ArrowLeft className="mr-2 h-4 w-4" />
                      Back to Payment
                    </Button>
                    <Link href="/order-confirmation">
                      <Button>
                        Place Order
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          <div>
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="border-b pb-4">
                    <div className="flex items-center gap-2">
                      <div className="h-16 w-16 relative bg-muted rounded">
                        <Image
                          src="/placeholder.svg?height=64&width=64"
                          alt="Product thumbnail"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div>
                        <p className="font-medium">Classic Fit T-Shirt</p>
                        <p className="text-sm text-muted-foreground">Size: M, Color: Black</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Subtotal</span>
                      <span>$29.99</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Shipping</span>
                      <span>Free</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Tax</span>
                      <span>$2.40</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between font-medium">
                      <span>Total</span>
                      <span>$32.39</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
