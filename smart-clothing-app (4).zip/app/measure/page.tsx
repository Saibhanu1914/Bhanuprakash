"use client"

import { useState, useRef, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { ArrowRight, Camera, Upload, X, Maximize2, RefreshCw, ShoppingBag } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"

export default function MeasurementPage() {
  const [measurementMethod, setMeasurementMethod] = useState("manual")
  const [uploadedImages, setUploadedImages] = useState({
    front: null,
    side: null,
  })
  const [showMeasurements, setShowMeasurements] = useState(false)
  const [measurements, setMeasurements] = useState({
    height: 175,
    weight: 70,
    chest: 92,
    waist: 76,
    hips: 94,
    shoulders: 45,
    armLength: 62,
    inseam: 81,
    thigh: 56,
  })
  const [isProcessing, setIsProcessing] = useState(false)
  const [processingProgress, setProcessingProgress] = useState(0)
  const [cameraActive, setCameraActive] = useState(false)
  const [activeCamera, setActiveCamera] = useState("front")
  const videoRef = useRef(null)
  const streamRef = useRef(null)

  // Product recommendations based on body measurements
  const recommendedProducts = [
    {
      id: 1,
      name: "Perfect Fit T-Shirt",
      price: "$29.99",
      image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&auto=format&fit=crop&q=60",
      color: "Navy Blue",
      fit: "Perfect fit",
      matchScore: 98,
    },
    {
      id: 2,
      name: "Slim Fit Jeans",
      price: "$59.99",
      image: "https://images.unsplash.com/photo-1542272604-787c3835535d?w=500&auto=format&fit=crop&q=60",
      color: "Dark Blue",
      fit: "Slightly slim",
      matchScore: 95,
    },
    {
      id: 3,
      name: "Casual Blazer",
      price: "$89.99",
      image: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=500&auto=format&fit=crop&q=60",
      color: "Charcoal",
      fit: "Perfect fit",
      matchScore: 97,
    },
    {
      id: 4,
      name: "Summer Dress",
      price: "$49.99",
      image: "https://images.unsplash.com/photo-1612336307429-8a898d10e223?w=500&auto=format&fit=crop&q=60",
      color: "Floral",
      fit: "Relaxed fit",
      matchScore: 94,
    },
    {
      id: 5,
      name: "Formal Shirt",
      price: "$39.99",
      image: "https://images.unsplash.com/photo-1598033129183-c4f50c736f10?w=500&auto=format&fit=crop&q=60",
      color: "White",
      fit: "Perfect fit",
      matchScore: 96,
    },
    {
      id: 6,
      name: "Athletic Shorts",
      price: "$34.99",
      image: "https://images.unsplash.com/photo-1562886877-aaaa5c0b3225?w=500&auto=format&fit=crop&q=60",
      color: "Black",
      fit: "Athletic fit",
      matchScore: 99,
    },
    {
      id: 7,
      name: "Casual Sweater",
      price: "$45.99",
      image: "https://images.unsplash.com/photo-1576871337622-98d48d1cf531?w=500&auto=format&fit=crop&q=60",
      color: "Burgundy",
      fit: "Relaxed fit",
      matchScore: 93,
    },
    {
      id: 8,
      name: "Tailored Pants",
      price: "$69.99",
      image: "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=500&auto=format&fit=crop&q=60",
      color: "Khaki",
      fit: "Perfect fit",
      matchScore: 97,
    },
    {
      id: 9,
      name: "Denim Jacket",
      price: "$79.99",
      image: "https://images.unsplash.com/photo-1495105787522-5334e3ffa0ef?w=500&auto=format&fit=crop&q=60",
      color: "Light Blue",
      fit: "Slightly loose",
      matchScore: 92,
    },
    {
      id: 10,
      name: "Knit Cardigan",
      price: "$54.99",
      image: "https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=500&auto=format&fit=crop&q=60",
      color: "Gray",
      fit: "Perfect fit",
      matchScore: 96,
    },
  ]

  // Handle image upload
  const handleImageUpload = (view, e) => {
    const file = e.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setUploadedImages((prev) => ({
          ...prev,
          [view]: e.target.result,
        }))

        // If both images are uploaded, process measurements
        if ((view === "side" && uploadedImages.front) || (view === "front" && uploadedImages.side)) {
          processBodyMeasurements()
        }
      }
      reader.readAsDataURL(file)
    }
  }

  // Process body measurements from images
  const processBodyMeasurements = () => {
    setIsProcessing(true)

    // Simulate processing with progress
    let progress = 0
    const interval = setInterval(() => {
      progress += 5
      setProcessingProgress(progress)

      if (progress >= 100) {
        clearInterval(interval)
        setIsProcessing(false)
        setShowMeasurements(true)

        // Simulate slightly different measurements based on images
        setMeasurements({
          height: Math.floor(170 + Math.random() * 15),
          weight: Math.floor(65 + Math.random() * 15),
          chest: Math.floor(88 + Math.random() * 10),
          waist: Math.floor(72 + Math.random() * 10),
          hips: Math.floor(90 + Math.random() * 10),
          shoulders: Math.floor(42 + Math.random() * 8),
          armLength: Math.floor(58 + Math.random() * 8),
          inseam: Math.floor(78 + Math.random() * 8),
          thigh: Math.floor(52 + Math.random() * 8),
        })
      }
    }, 100)
  }

  // Camera access functions
  const startCamera = async (view) => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true })
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        streamRef.current = stream
        setCameraActive(true)
        setActiveCamera(view)
      }
    } catch (err) {
      console.error("Error accessing camera:", err)
      alert("Could not access camera. Please check permissions.")
    }
  }

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
      setCameraActive(false)
    }
  }

  const capturePhoto = (view) => {
    if (videoRef.current && streamRef.current) {
      const canvas = document.createElement("canvas")
      canvas.width = videoRef.current.videoWidth
      canvas.height = videoRef.current.videoHeight
      const ctx = canvas.getContext("2d")
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height)
      const imageDataUrl = canvas.toDataURL("image/jpeg")

      setUploadedImages((prev) => ({
        ...prev,
        [view]: imageDataUrl,
      }))

      stopCamera()

      // If both images are uploaded, process measurements
      if ((view === "side" && uploadedImages.front) || (view === "front" && uploadedImages.side)) {
        processBodyMeasurements()
      }
    }
  }

  // Clean up camera on unmount
  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop())
      }
    }
  }, [])

  return (
    <div className="container max-w-4xl py-10">
      <div className="flex flex-col space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 text-transparent bg-clip-text">
            Body Measurements
          </h1>
          <p className="text-muted-foreground">Provide your measurements for the most accurate fit recommendations.</p>
        </div>

        <Tabs
          defaultValue="manual"
          onValueChange={setMeasurementMethod}
          className="bg-gradient-to-r from-pink-50 via-purple-50 to-indigo-50 p-1 rounded-lg"
        >
          <TabsList className="grid w-full grid-cols-3 bg-white/50 backdrop-blur-sm">
            <TabsTrigger value="manual" className="data-[state=active]:bg-white data-[state=active]:text-pink-600">
              Manual Entry
            </TabsTrigger>
            <TabsTrigger value="photo" className="data-[state=active]:bg-white data-[state=active]:text-purple-600">
              Photo Upload
            </TabsTrigger>
            <TabsTrigger value="scan" className="data-[state=active]:bg-white data-[state=active]:text-indigo-600">
              3D Body Scan
            </TabsTrigger>
          </TabsList>

          <TabsContent value="manual" className="pt-6">
            <Card className="border-pink-200">
              <CardHeader className="bg-gradient-to-r from-pink-50 to-pink-100 rounded-t-lg">
                <CardTitle className="text-pink-700">Enter Your Measurements</CardTitle>
                <CardDescription>Input your body measurements manually for the most accurate fit.</CardDescription>
              </CardHeader>
              <CardContent>
                <form className="grid gap-6">
                  <div className="grid gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="gender">Body Type</Label>
                      <RadioGroup defaultValue="female" className="flex gap-4">
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="female" id="female" className="text-pink-600" />
                          <Label htmlFor="female">Female</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="male" id="male" className="text-blue-600" />
                          <Label htmlFor="male">Male</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="other" id="other" className="text-purple-600" />
                          <Label htmlFor="other">Other</Label>
                        </div>
                      </RadioGroup>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="height">Height (cm)</Label>
                        <Input
                          id="height"
                          type="number"
                          placeholder="175"
                          className="border-pink-200 focus-visible:ring-pink-400"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="weight">Weight (kg)</Label>
                        <Input
                          id="weight"
                          type="number"
                          placeholder="70"
                          className="border-pink-200 focus-visible:ring-pink-400"
                        />
                      </div>
                    </div>

                    <Separator className="bg-pink-200" />
                    <h3 className="text-lg font-medium text-pink-700">Upper Body</h3>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="chest">Chest (cm)</Label>
                        <Input
                          id="chest"
                          type="number"
                          placeholder="90"
                          className="border-pink-200 focus-visible:ring-pink-400"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="waist">Waist (cm)</Label>
                        <Input
                          id="waist"
                          type="number"
                          placeholder="75"
                          className="border-pink-200 focus-visible:ring-pink-400"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="shoulders">Shoulders (cm)</Label>
                        <Input
                          id="shoulders"
                          type="number"
                          placeholder="45"
                          className="border-pink-200 focus-visible:ring-pink-400"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="arm-length">Arm Length (cm)</Label>
                        <Input
                          id="arm-length"
                          type="number"
                          placeholder="60"
                          className="border-pink-200 focus-visible:ring-pink-400"
                        />
                      </div>
                    </div>

                    <Separator className="bg-pink-200" />
                    <h3 className="text-lg font-medium text-pink-700">Lower Body</h3>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="hips">Hips (cm)</Label>
                        <Input
                          id="hips"
                          type="number"
                          placeholder="95"
                          className="border-pink-200 focus-visible:ring-pink-400"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="inseam">Inseam (cm)</Label>
                        <Input
                          id="inseam"
                          type="number"
                          placeholder="80"
                          className="border-pink-200 focus-visible:ring-pink-400"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="thigh">Thigh (cm)</Label>
                        <Input
                          id="thigh"
                          type="number"
                          placeholder="55"
                          className="border-pink-200 focus-visible:ring-pink-400"
                        />
                      </div>
                    </div>
                  </div>
                </form>
              </CardContent>
              <CardFooter className="bg-gradient-to-r from-pink-50 to-pink-100 rounded-b-lg">
                <Link href="/try-on" className="ml-auto">
                  <Button className="bg-pink-600 hover:bg-pink-700">
                    Continue to Try-On
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="photo" className="pt-6">
            <Card className="border-purple-200">
              <CardHeader className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-t-lg">
                <CardTitle className="text-purple-700">Upload Photos</CardTitle>
                <CardDescription>
                  Upload front and side photos to automatically calculate your measurements.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isProcessing ? (
                  <div className="flex flex-col items-center gap-4 py-8">
                    <div className="w-full max-w-md">
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Processing images...</span>
                        <span className="text-sm font-medium">{processingProgress}%</span>
                      </div>
                      <Progress
                        value={processingProgress}
                        className="h-2 bg-purple-100"
                        indicatorClassName="bg-purple-600"
                      />
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Our AI is analyzing your photos to calculate accurate body measurements.
                    </p>
                  </div>
                ) : showMeasurements ? (
                  <div className="grid gap-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="font-medium text-purple-700 mb-4">Your Photos</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="relative">
                            <img
                              src={uploadedImages.front || "/placeholder.svg"}
                              alt="Front view"
                              className="w-full h-48 object-cover rounded-lg border-2 border-purple-300"
                            />
                            <Badge className="absolute top-2 right-2 bg-purple-600">Front</Badge>
                          </div>
                          <div className="relative">
                            <img
                              src={uploadedImages.side || "/placeholder.svg"}
                              alt="Side view"
                              className="w-full h-48 object-cover rounded-lg border-2 border-purple-300"
                            />
                            <Badge className="absolute top-2 right-2 bg-purple-600">Side</Badge>
                          </div>
                        </div>
                        <Button
                          variant="outline"
                          className="mt-4 border-purple-300 text-purple-700 hover:bg-purple-50"
                          onClick={() => {
                            setUploadedImages({ front: null, side: null })
                            setShowMeasurements(false)
                          }}
                        >
                          <RefreshCw className="mr-2 h-4 w-4" />
                          Retake Photos
                        </Button>
                      </div>

                      <div>
                        <h3 className="font-medium text-purple-700 mb-4">Your Measurements</h3>
                        <div className="space-y-3 bg-purple-50 p-4 rounded-lg">
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <p className="text-sm text-muted-foreground">Height</p>
                              <p className="font-medium">{measurements.height} cm</p>
                            </div>
                            <div>
                              <p className="text-sm text-muted-foreground">Weight</p>
                              <p className="font-medium">{measurements.weight} kg</p>
                            </div>
                          </div>

                          <Separator className="bg-purple-200" />

                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <p className="text-sm text-muted-foreground">Chest</p>
                              <p className="font-medium">{measurements.chest} cm</p>
                            </div>
                            <div>
                              <p className="text-sm text-muted-foreground">Waist</p>
                              <p className="font-medium">{measurements.waist} cm</p>
                            </div>
                            <div>
                              <p className="text-sm text-muted-foreground">Hips</p>
                              <p className="font-medium">{measurements.hips} cm</p>
                            </div>
                            <div>
                              <p className="text-sm text-muted-foreground">Shoulders</p>
                              <p className="font-medium">{measurements.shoulders} cm</p>
                            </div>
                            <div>
                              <p className="text-sm text-muted-foreground">Arm Length</p>
                              <p className="font-medium">{measurements.armLength} cm</p>
                            </div>
                            <div>
                              <p className="text-sm text-muted-foreground">Inseam</p>
                              <p className="font-medium">{measurements.inseam} cm</p>
                            </div>
                            <div>
                              <p className="text-sm text-muted-foreground">Thigh</p>
                              <p className="font-medium">{measurements.thigh} cm</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <Separator className="bg-purple-200" />

                    <div>
                      <h3 className="font-medium text-purple-700 mb-4">Recommended Products For Your Body Type</h3>
                      <ScrollArea className="h-[320px] rounded-md border border-purple-200 p-4">
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                          {recommendedProducts.map((product) => (
                            <div
                              key={product.id}
                              className="border border-purple-200 rounded-lg overflow-hidden bg-white hover:shadow-md transition-shadow"
                            >
                              <div className="relative">
                                <Image
                                  src={product.image || "/placeholder.svg"}
                                  alt={product.name}
                                  width={150}
                                  height={200}
                                  className="w-full h-40 object-cover"
                                  unoptimized
                                />
                                <Badge className="absolute top-2 right-2 bg-green-600">
                                  {product.matchScore}% Match
                                </Badge>
                              </div>
                              <div className="p-3">
                                <h4 className="font-medium text-sm line-clamp-1">{product.name}</h4>
                                <p className="text-sm text-muted-foreground">{product.price}</p>
                                <div className="flex items-center justify-between mt-2">
                                  <span className="text-xs text-purple-700">{product.fit}</span>
                                  <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                                    <ShoppingBag className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                    </div>
                  </div>
                ) : (
                  <div className="grid gap-6">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex flex-col items-center gap-2">
                        {uploadedImages.front ? (
                          <div className="relative w-full">
                            <img
                              src={uploadedImages.front || "/placeholder.svg"}
                              alt="Front view"
                              className="w-full h-48 object-cover rounded-lg border-2 border-purple-300"
                            />
                            <div className="absolute bottom-2 right-2 flex gap-2">
                              <Button
                                variant="secondary"
                                size="sm"
                                className="bg-white/80 backdrop-blur-sm hover:bg-white"
                                onClick={() => setUploadedImages((prev) => ({ ...prev, front: null }))}
                              >
                                <X className="h-4 w-4" />
                              </Button>
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button
                                    variant="secondary"
                                    size="sm"
                                    className="bg-white/80 backdrop-blur-sm hover:bg-white"
                                  >
                                    <Maximize2 className="h-4 w-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="max-w-2xl">
                                  <DialogHeader>
                                    <DialogTitle>Front View</DialogTitle>
                                  </DialogHeader>
                                  <div className="mt-4">
                                    <img
                                      src={uploadedImages.front || "/placeholder.svg"}
                                      alt="Front view"
                                      className="w-full h-auto max-h-[70vh] object-contain"
                                    />
                                  </div>
                                </DialogContent>
                              </Dialog>
                            </div>
                          </div>
                        ) : (
                          <div className="w-full">
                            {cameraActive && activeCamera === "front" ? (
                              <div className="relative">
                                <video
                                  ref={videoRef}
                                  autoPlay
                                  className="w-full h-48 object-cover rounded-lg border-2 border-purple-300"
                                />
                                <div className="absolute bottom-2 right-2 flex gap-2">
                                  <Button
                                    variant="secondary"
                                    size="sm"
                                    className="bg-white/80 backdrop-blur-sm hover:bg-white"
                                    onClick={stopCamera}
                                  >
                                    <X className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    variant="secondary"
                                    size="sm"
                                    className="bg-purple-600 text-white hover:bg-purple-700"
                                    onClick={() => capturePhoto("front")}
                                  >
                                    <Camera className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            ) : (
                              <div className="flex flex-col gap-2">
                                <div
                                  className="border-2 border-dashed border-purple-300 rounded-lg p-12 flex flex-col items-center justify-center gap-2 cursor-pointer hover:bg-purple-50"
                                  onClick={() => document.getElementById("front-view-upload").click()}
                                >
                                  <input
                                    type="file"
                                    id="front-view-upload"
                                    className="hidden"
                                    accept="image/*"
                                    onChange={(e) => handleImageUpload("front", e)}
                                  />
                                  <Camera className="h-8 w-8 text-purple-500" />
                                  <p className="text-sm text-purple-700 text-center">Front View</p>
                                  <p className="text-xs text-muted-foreground text-center">Click to upload a photo</p>
                                </div>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="border-purple-300 text-purple-700 hover:bg-purple-50"
                                  onClick={() => startCamera("front")}
                                >
                                  <Camera className="mr-2 h-4 w-4" />
                                  Take Photo
                                </Button>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                      <div className="flex flex-col items-center gap-2">
                        {uploadedImages.side ? (
                          <div className="relative w-full">
                            <img
                              src={uploadedImages.side || "/placeholder.svg"}
                              alt="Side view"
                              className="w-full h-48 object-cover rounded-lg border-2 border-purple-300"
                            />
                            <div className="absolute bottom-2 right-2 flex gap-2">
                              <Button
                                variant="secondary"
                                size="sm"
                                className="bg-white/80 backdrop-blur-sm hover:bg-white"
                                onClick={() => setUploadedImages((prev) => ({ ...prev, side: null }))}
                              >
                                <X className="h-4 w-4" />
                              </Button>
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button
                                    variant="secondary"
                                    size="sm"
                                    className="bg-white/80 backdrop-blur-sm hover:bg-white"
                                  >
                                    <Maximize2 className="h-4 w-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="max-w-2xl">
                                  <DialogHeader>
                                    <DialogTitle>Side View</DialogTitle>
                                  </DialogHeader>
                                  <div className="mt-4">
                                    <img
                                      src={uploadedImages.side || "/placeholder.svg"}
                                      alt="Side view"
                                      className="w-full h-auto max-h-[70vh] object-contain"
                                    />
                                  </div>
                                </DialogContent>
                              </Dialog>
                            </div>
                          </div>
                        ) : (
                          <div className="w-full">
                            {cameraActive && activeCamera === "side" ? (
                              <div className="relative">
                                <video
                                  ref={videoRef}
                                  autoPlay
                                  className="w-full h-48 object-cover rounded-lg border-2 border-purple-300"
                                />
                                <div className="absolute bottom-2 right-2 flex gap-2">
                                  <Button
                                    variant="secondary"
                                    size="sm"
                                    className="bg-white/80 backdrop-blur-sm hover:bg-white"
                                    onClick={stopCamera}
                                  >
                                    <X className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    variant="secondary"
                                    size="sm"
                                    className="bg-purple-600 text-white hover:bg-purple-700"
                                    onClick={() => capturePhoto("side")}
                                  >
                                    <Camera className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            ) : (
                              <div className="flex flex-col gap-2">
                                <div
                                  className="border-2 border-dashed border-purple-300 rounded-lg p-12 flex flex-col items-center justify-center gap-2 cursor-pointer hover:bg-purple-50"
                                  onClick={() => document.getElementById("side-view-upload").click()}
                                >
                                  <input
                                    type="file"
                                    id="side-view-upload"
                                    className="hidden"
                                    accept="image/*"
                                    onChange={(e) => handleImageUpload("side", e)}
                                  />
                                  <Camera className="h-8 w-8 text-purple-500" />
                                  <p className="text-sm text-purple-700 text-center">Side View</p>
                                  <p className="text-xs text-muted-foreground text-center">Click to upload a photo</p>
                                </div>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="border-purple-300 text-purple-700 hover:bg-purple-50"
                                  onClick={() => startCamera("side")}
                                >
                                  <Camera className="mr-2 h-4 w-4" />
                                  Take Photo
                                </Button>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <p className="text-sm text-purple-700 font-medium">For best results:</p>
                      <ul className="text-sm text-muted-foreground list-disc pl-5 space-y-1">
                        <li>Wear form-fitting clothes</li>
                        <li>Stand against a plain background</li>
                        <li>Position yourself 2-3 meters from the camera</li>
                        <li>Ensure good lighting</li>
                        <li>Stand with arms slightly away from body</li>
                      </ul>
                    </div>
                  </div>
                )}
              </CardContent>
              <CardFooter className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-b-lg flex justify-between">
                {!showMeasurements ? (
                  <>
                    <Button
                      variant="outline"
                      className="border-purple-300 text-purple-700 hover:bg-purple-50"
                      onClick={() => {
                        if (uploadedImages.front && uploadedImages.side) {
                          processBodyMeasurements()
                        }
                      }}
                      disabled={!uploadedImages.front || !uploadedImages.side}
                    >
                      <Upload className="mr-2 h-4 w-4" />
                      Process Images
                    </Button>
                    <Link href="/try-on">
                      <Button
                        className="bg-purple-600 hover:bg-purple-700"
                        disabled={!uploadedImages.front && !uploadedImages.side}
                      >
                        Continue to Try-On
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </>
                ) : (
                  <Link href="/try-on" className="ml-auto">
                    <Button className="bg-purple-600 hover:bg-purple-700">
                      Continue to Try-On
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                )}
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="scan" className="pt-6">
            <Card className="border-indigo-200">
              <CardHeader className="bg-gradient-to-r from-indigo-50 to-indigo-100 rounded-t-lg">
                <CardTitle className="text-indigo-700">3D Body Scan</CardTitle>
                <CardDescription>
                  Use our advanced 3D scanning technology for the most accurate measurements.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-8">
                  <div className="flex flex-col items-center gap-6 py-4">
                    <div className="rounded-full bg-indigo-100 p-6">
                      <Camera className="h-12 w-12 text-indigo-600" />
                    </div>
                    <div className="text-center space-y-2">
                      <h3 className="font-medium text-indigo-700">Download Our Mobile App</h3>
                      <p className="text-sm text-muted-foreground max-w-md">
                        Our mobile app uses your phone's camera to create a detailed 3D model of your body, providing
                        the most accurate measurements possible.
                      </p>
                    </div>
                    <div className="flex gap-4">
                      <Button variant="outline" className="border-indigo-300 text-indigo-700 hover:bg-indigo-50">
                        Download for iOS
                      </Button>
                      <Button variant="outline" className="border-indigo-300 text-indigo-700 hover:bg-indigo-50">
                        Download for Android
                      </Button>
                    </div>
                  </div>

                  <div className="relative h-[300px] bg-gradient-to-b from-indigo-100/50 to-indigo-200/50 rounded-lg overflow-hidden flex items-center justify-center">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-[120px] h-[280px] bg-indigo-500/20 rounded-full animate-pulse"></div>
                    </div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div
                        className="w-[100px] h-[260px] bg-indigo-600/20 rounded-full animate-pulse"
                        style={{ animationDelay: "0.5s" }}
                      ></div>
                    </div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div
                        className="w-[80px] h-[240px] bg-indigo-700/20 rounded-full animate-pulse"
                        style={{ animationDelay: "1s" }}
                      ></div>
                    </div>
                    <div className="relative z-10 text-center">
                      <h3 className="font-medium text-indigo-900 mb-2">3D Body Model</h3>
                      <p className="text-sm text-indigo-700">Scan your body to create a precise digital twin</p>
                      <div className="mt-4">
                        <Badge className="bg-indigo-600">360° Precision</Badge>
                      </div>
                    </div>
                  </div>
                </div>

                <Separator className="my-8 bg-indigo-200" />

                <div className="space-y-6">
                  <h3 className="font-medium text-indigo-700">How 3D Scanning Works</h3>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card className="border-indigo-200">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base">Step 1: Scan</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground">
                          Use our app to scan your body from all angles. The process takes less than 30 seconds.
                        </p>
                      </CardContent>
                    </Card>

                    <Card className="border-indigo-200">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base">Step 2: Process</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground">
                          Our AI processes the scan to create a precise 3D model with over 100 measurement points.
                        </p>
                      </CardContent>
                    </Card>

                    <Card className="border-indigo-200">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base">Step 3: Shop</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground">
                          Use your 3D model to virtually try on clothes and find your perfect fit.
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="bg-gradient-to-r from-indigo-50 to-indigo-100 rounded-b-lg flex justify-between">
                <p className="text-sm text-muted-foreground">
                  Already have a scan?{" "}
                  <Link href="#" className="text-indigo-600 hover:underline">
                    Sign in
                  </Link>{" "}
                  to access it.
                </p>
                <Link href="/try-on">
                  <Button className="bg-indigo-600 hover:bg-indigo-700">
                    Continue to Try-On
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
